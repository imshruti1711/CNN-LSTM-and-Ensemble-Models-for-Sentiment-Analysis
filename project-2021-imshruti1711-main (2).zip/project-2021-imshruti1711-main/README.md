# ST449-project-2021

This is the repository for the course project. Please keep anything project related in this repository.

**Important dates**:
   * **Project proposal deadline**: 14th March, 5pm London UK time (fill in the information below by this date)
   * **First notification deadline**: 28th March, 5pm London UK time (approval of project topic or request for revision by this date)
   * **Project topic approval deadline**: 31st March, 5pm London UK time (all project topics must be approved by this date)
   * **Project solution submission deadline**: 30th April, 5pm London UK time

Your first task is the propose your project topic by filling the information requested below. 

You are encouraged to propose your course project topic as soon as possible but not later than by the project proposal deadline indicated above. We will try to process your project proposal and provide feedback as soon as possible. In any case, the first feedback from us will not be later than by the first notification deadline indicated above. All project topics must be approved by the project approval deadline indicated above -- the approval will be indicated in the feedback section below. 

You will receive feedback for your project topic proposal in the feedback section below of this Markdown file. A project topic proposal may be immediately approved or some revision may be required. The feedback should be limited to a few rounds of interactions (one or two) in order to deal with the workload. 

---

Please add the following information:

## Project title:

Sentiment Analysis of IMDB movie reviews 


## Summary:

The rising demand for digital entertainment and stiff competition among various players in the industry make it crucial for OTT platforms to develop a robust technique to understand customer preferences. Sentiment Analysis of IMDB movie reviews is one such cutting-edge method to achieve this. The aim of this project is to determine the best deep learning technique for sentiment analysis so that the results obtained are reliable and efficient. This project uses two deep learning techniques- CNN and LSTM to perform sentiment analysis on the keras imdb dataset. For optimising the results obtained using both these models, this project would use Hparams to determine the optimal number of convolutional layers, number of units and nodes in the dense layer, learning rate, dropout rate, optimizer and L2 regulariser which yield the highest prediction accuracy. This project also builds an ensemble model using CNN and LSTM to combine the strengths of both (an active research area). Finally, it compares the performance of the CNN, LSTM and ensemble models to determine the best technique for sentiment analysis of IMDB movie reviews.   

 
## References:

 
https://sentic.net/convolutional-and-recurrent-neural-networks-for-text-categorization.pdf

https://machinelearningmastery.com/when-to-use-mlp-cnn-and-rnn-neural-networks/

https://link.springer.com/article/10.1007/s10462-020-09845-2

https://arxiv.org/abs/2006.03541

https://arxiv.org/ftp/arxiv/papers/2005/2005.03993.pdf

https://stackabuse.com/python-for-nlp-movie-sentiment-analysis-using-deep-learning-in-keras/

https://missinglink.ai/guides/neural-network-concepts/cnn-vs-rnn-neural-network-right/


---

## Feedback:

* [MV, 27 March 2021] Approved. You may want to focus on the underlying deep learning methodology - explain well the models used, rationale behind various design choices, implement and evaluate your methods. You may want to be selective in the choice of references on which you base your project -- focusing on those that have made notable contributions, which are often published in top-tier machine learning conferences. 


---


## Candidate project topics: 

Here you may find information about some candidate project topics: [Project.md](https://github.com/lse-st449/lectures2021/blob/master/Projects.md).

**Important**: You do not need to take a project topic listed in our list of suggestions -- you are encourged to come up with a project topic proposal of your own, which is not listed in our list.


## Marking criteria:

<img src="https://github.com/lse-st449/lectures2021/blob/main/images/ST449-final-coursework-rubric.png"></img>
 
